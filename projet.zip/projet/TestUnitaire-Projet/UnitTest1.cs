using System;
using Xunit;
using Projet;
using System.Collections.Generic;

namespace TestUnitaire_Projet
{
    public class UnitTest1
    {
        [Fact]
        public void TestParcoursLargeur()
        {
            // Arrange
            var graphe = new Graphe(5);
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var chemin = graphe.ParcoursLargeur(1);

            // Assert
            Assert.Equal(new List<int> { 1, 2, 3, 4 }, chemin);
        }

        [Fact]
        public void TestAjouterLien()
        {
            // Arrange
            var graphe = new Graphe();

            // Act
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);

            // Assert
            Assert.True(graphe.Noeuds.ContainsKey(1));
            Assert.True(graphe.Noeuds.ContainsKey(2));
            Assert.True(graphe.Noeuds.ContainsKey(3));
            Assert.Equal(2, graphe.Liens.Count);
            Assert.Contains(2, graphe.ListeAdjacence[1]);
            Assert.Contains(1, graphe.ListeAdjacence[2]);
            Assert.Contains(3, graphe.ListeAdjacence[2]);
            Assert.Contains(2, graphe.ListeAdjacence[3]);
            Assert.True(graphe.MatriceAdjacence[1, 2]);
            Assert.True(graphe.MatriceAdjacence[2, 1]);
            Assert.True(graphe.MatriceAdjacence[2, 3]);
            Assert.True(graphe.MatriceAdjacence[3, 2]);
        }

        [Fact]
        public void TestParcoursProfondeur()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var chemin = graphe.ParcoursProfondeur(1);

            // Assert
            Assert.Equal(new List<int> { 1, 2, 3, 4 }, chemin);
        }

        [Fact]
        public void TestTrouverCheminCourt()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var chemin = graphe.TrouverCheminCourt(1, 4);

            // Assert
            Assert.Equal(new List<int> { 1, 2, 3, 4 }, chemin);
        }

        [Fact]
        public void TestEstConnexe()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var estConnexe = graphe.EstConnexe();

            // Assert
            Assert.True(estConnexe);
        }

        [Fact]
        public void TestContientDesCycles()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 1);

            // Act
            var contientCycles = graphe.ContientDesCycles();

            // Assert
            Assert.True(contientCycles);
        }

        [Fact]
        public void TestOrdreGraphe()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var ordre = graphe.OrdreGraphe;

            // Assert
            Assert.Equal(4, ordre);
        }

        [Fact]
        public void TestTailleGraphe()
        {
            // Arrange
            var graphe = new Graphe();
            graphe.AjouterLien(1, 2);
            graphe.AjouterLien(2, 3);
            graphe.AjouterLien(3, 4);

            // Act
            var taille = graphe.TailleGraphe;

            // Assert
            Assert.Equal(3, taille);
        }


        [Fact]
        public void Noeud_CreationAvecId_StockeIdCorrectement()
        {
            // Arrange
            int id = 1;

            // Act
            Noeud noeud = new Noeud(id);

            // Assert
            Assert.Equal(id, noeud.Id);
        }

        [Fact]
        public void Lien_CreationAvecDeuxNoeuds_StockeNoeudsCorrectement()
        {
            // Arrange
            Noeud noeud1 = new Noeud(1);
            Noeud noeud2 = new Noeud(2);

            // Act
            Lien lien = new Lien(noeud1, noeud2);

            // Assert
            Assert.Equal(noeud1, lien.Noeud1);
            Assert.Equal(noeud2, lien.Noeud2);
        }

        [Fact]
        public void Lien_CreationAvecNoeudsNull_ThrowsException()
        {
            // Arrange
            Noeud noeud1 = null;
            Noeud noeud2 = new Noeud(2);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => new Lien(noeud1, noeud2));
            Assert.Throws<ArgumentNullException>(() => new Lien(noeud2, null));
        }
    }
}

